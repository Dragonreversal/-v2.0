# 抓包字节对比工具 v2.0 (Packet Compare)

> **用途**: 捕获任意目标进程的所有网络流量，对比用户开启任意封包工具(exe程序)前后的字节差异。
> **底层**: WinDivert 2.2.2 (kernel-level packet capture) + 自研字节级 diff 引擎。
> **目标场景**: 验证 WPE/FightMaster/封包修改工具对游戏流量的实际修改痕迹，或任意进程的流量对比分析。
---

## 一、目录结构

```
packet_compare\                          ← 整个工具根目录(可重命名)
├── PacketTool.cs                        ← 工具源码(C# .NET 4.0+)
├── run.ps1                              ← 通用 PowerShell 包装脚本(推荐入口)
├── README.md                            ← 本说明
└── windivert\
    └── WinDivert-2.2.2-A\
        ├── LICENSE                      ← WinDivert LGPLv3 许可证(必须保留)
        └── x64\
            ├── PacketTool.exe           ← 编译产物 v2.0
            ├── WinDivert.dll            ← P/Invoke 所需(运行时加载)
            └── WinDivert64.sys          ← 内核驱动
```

**关键点**: `PacketTool.exe` 必须和 `WinDivert.dll`、`WinDivert64.sys` 在同一目录，否则 P/Invoke 会失败。

---

## 二、前置条件

1. **Windows 系统** (Win7+，x64)
2. **.NET Framework 4.0+** (系统自带，无需安装)
3. **管理员权限** (WinDivert 需要加载内核驱动)
4. **WinDivert 驱动** 只需安装一次：
   ```powershell
   # 以管理员身份打开 PowerShell
   cd <工具根目录>
   .\run.ps1 setup
   ```
   成功后显示 `[OK] WinDivert driver is running`。

> **可移植性说明**: 整个 `packet_compare\` 目录可以复制到任何 Windows 机器(如 `C:\Tools\packet_compare\`、`D:\...\` 等)，所有路径基于脚本所在目录自动定位，不依赖任何固定路径。

---

## 三、快速开始(典型工作流)

### 场景: 验证某 EXE 封包工具对进程 P 的修改痕迹

#### 步骤 1: 确认目标进程

```powershell
# 列出所有匹配进程名(支持通配符 *)
.\run.ps1 listproc chrome                # 浏览器
.\run.ps1 listproc dnplayer*             # 雷电模拟器
.\run.ps1 listproc GameLoop*             # 腾讯手游助手

# 查看某 PID/进程名的全部 TCP+UDP 连接
.\run.ps1 listpid chrome
.\run.ps1 listpid 12345
```

#### 步骤 2: 抓"未启用封包工具"的流量(场景 A)

```powershell
# 启动目标进程(不要启动封包工具)
# 然后开始抓包(Ctrl+C 停止)
.\run.ps1 capture captures\A.pcap --pname chrome --stats 5
```

- `--pname chrome` 聚合所有匹配进程的连接(子进程聚合)
- `--stats 5` 每 5 秒打印 per-flow 字节统计
- 不指定 `--duration` 默认无限,按 `Ctrl+C` 停止

抓包过程中会实时显示:
```
[*] Captured 500 packets (89437 bytes), 12 flows
[*] Captured 1500 packets (2341289 bytes), 18 flows
--- PERIODIC Flow Stats (18 flows) ---
    1234567 bytes  192.168.1.2:50000-175.6.84.37:24863
     234567 bytes  192.168.1.2:49999-58.218.65.8:443
...
```

#### 步骤 3: 抓"启用封包工具"的流量(场景 B)

```powershell
# 启动封包工具(如 FightMaster / WPE)
# 然后开始抓包
.\run.ps1 capture captures\B.pcap --pname chrome --stats 5
```

> **关键**: 两次抓包的"操作场景"应尽可能一致(同一游戏流程、同一时长)，这样字节差异才有意义。

#### 步骤 4: 字节级对比

```powershell
.\run.ps1 compare captures\A.pcap captures\B.pcap --report reports\diff.txt --detail --bin reports\diff
```

参数说明:
- `--report reports\diff.txt`: 报告输出到文件
- `--detail`: 显示完整 hex+ASCII 上下文
- `--bin reports\diff`: 同时导出每个 DIFF 流的原始字节(`_diff_N_c2s_A.bin` / `_diff_N_c2s_B.bin` 等)

报告输出样例:
```
=== Packet Byte Comparison Report ===
File A: captures\A.pcap
File B: captures\B.pcap
Flows A: 138, Flows B: 6444

[ONLY-A] 192.168.1.2:49999-113.240.76.246:443  (packets=5, bytes=1234)
[ONLY-B] 192.168.1.2:50000-43.135.128.1:17500  (packets=200, bytes=45678)
[DIFF] 175.6.84.37:24863-192.168.1.2:49998 dir=c2s  lenA=94 lenB=94
  First diff at byte: 0 (0x0)
  Different bytes (overlap region): 94
  Length diff: 0 bytes
  --- Context (A) at offset 0 ---
  4F 6A 68 4F 6A 4F 36 4E 6B 46 09 4F 6A 4F 6A 20 | OjhOjO6NkF.OjOj 
  --- Context (B) at offset 0 ---
  35 08 0A 35 08 35 54 34 09 3C 6B 35 08 35 08 5A | 5.5.5T4.<k5.5.Z

=== Summary ===
Total flows: 6566
Only in A: 122
Only in B: 6428
Same: 7
Different: 9
```

#### 步骤 5: 单流深度导出(可选)

```powershell
# 把某条流的 c2s/s2c 双向字节分别导出为 .bin 和 .txt
.\run.ps1 dumpflow captures\A.pcap 175.6.84.37 24863 --out reports\flowA_24863
.\run.ps1 dumpflow captures\B.pcap 175.6.84.37 24863 --out reports\flowB_24863
```

输出:
- `flowA_24863_c2s.bin` / `flowA_24863_c2s.txt` — client→server 方向字节(hex)
- `flowA_24863_s2c.bin` / `flowA_24863_s2c.txt` — server→client 方向字节(hex)

---

## 四、命令完整参考

### 4.1 `run.ps1` 包装脚本(推荐入口)

```
.\run.ps1 <command> [args...]
```

| 命令 | 说明 |
|------|------|
| `setup` | 安装 WinDivert 内核驱动(只需一次) |
| `status` | 显示驱动状态、exe 路径、常见目标进程列表 |
| `listproc <pname>` | 列出所有匹配进程名的 PID、进程名、TCP 连接数、UDP 端点数 |
| `listpid <pid\|pname>` | 显示指定 PID/进程名的所有 TCP(ESTABLISHED) + UDP 端点 |
| `capture <out.pcap> [opts]` | 通用抓包(透传所有参数给 PacketTool.exe) |
| `compare <f1.pcap> <f2.pcap> [opts]` | 字节级对比(透传所有参数) |
| `dumpflow <pcap> <ip> <port> [opts]` | 单流导出(透传所有参数) |

### 4.2 `PacketTool.exe` 直接调用

#### `capture` — 抓包

```
PacketTool.exe capture <out.pcap> [options]
```

| 选项 | 说明 |
|------|------|
| `--pid <pid[,pid2...]>` | 指定一个或多个 PID(逗号分隔) |
| `--pname <name>` | 通过进程名查找 PID(支持 `*` 通配符)，自动聚合所有匹配进程 |
| `--port <p1,p2>` | 指定端口列表(TCP+UDP) |
| `--ip <addr>` | 指定 IP 地址 |
| `--duration <sec>` | 抓包时长秒数; **0=无限(默认)**, Ctrl+C 停止 |
| `--filter "<expr>"` | 直接传 WinDivert filter 表达式(覆盖自动构建) |
| `--full` | 抓取所有 IP 流量(不做进程/端口过滤) |
| `--stats <sec>` | 每 N 秒打印 per-flow 字节统计 |

**filter 自动构建规则**:
- 若指定 `--pid` 或 `--pname`: 把所有匹配进程的 TCP 远端 IP + 本地 TCP 端口 + 本地 UDP 端口 + DNS(53) 全部 OR 起来
- 若指定 `--port` 或 `--ip`: 用端口/IP 过滤(TCP+UDP 同时)
- 若指定 `--full`: filter=`ip` (全部 IP 流量)
- 若以上都不指定: filter=`ip`(默认全部)

#### `compare` — 字节级对比

```
PacketTool.exe compare <f1.pcap> <f2.pcap> [options]
```

| 选项 | 说明 |
|------|------|
| `--report <out.txt>` | 报告输出到文件 |
| `--port <p>` | 只对比包含此端口的流 |
| `--detail` | 显示完整 hex+ASCII 上下文 |
| `--flow <key>` | 只对比包含此关键字的流(如 `175.6.84.37`) |
| `--bin <prefix>` | 同时导出每个 DIFF 流的 A/B 原始字节 |

**对比逻辑**:
1. 按 4 元组(对称)聚合成 flow
2. 每个 flow 用 SYN 包判断 client/server (无 SYN 时取第一个有 payload 的包 src 为 client)
3. 对 c2s 和 s2c 两个方向分别按 SEQ 重组(TCP) 或时间序拼接(UDP)
4. 字节级比较,标记 ONLY-A / ONLY-B / DIFF / SAME
5. DIFF 流输出首个差异位置、不同字节数、长度差、上下文 hex dump

#### `dumpflow` — 单流导出

```
PacketTool.exe dumpflow <pcap> <ip> <port> [--out <base>]
```

输出 4 个文件:
- `<base>_c2s.bin` — client→server 字节
- `<base>_s2c.bin` — server→client 字节
- `<base>_c2s.txt` — hex+ASCII 文本
- `<base>_s2c.txt` — hex+ASCII 文本

#### `listpid <pid|pname>` — 列出进程连接

显示指定 PID 或进程名的所有 TCP(ESTABLISHED) 和 UDP 端点。

#### `listproc <pname>` — 列出匹配进程

显示所有匹配进程名的 PID、进程名、TCP 连接数、UDP 端点数。

---

## 五、v2.0 改进点(相对 v1)

| 改进 | v1 问题 | v2.0 修复 |
|------|---------|-----------|
| `dumpflow` 命令 | 仅在 usage 中声明,Main 中未实现 | 完整实现,导出 c2s/s2c 双向 .bin/.txt |
| `listpid` UDP | 只显示 TCP,不显示 UDP | 同时显示 TCP + UDP |
| c2s/s2c 方向 | 用 `SrcPort<DstPort` 判断不可靠(50000→80 误判) | 用 SYN 包判定 client, 无 SYN 时取第一个有 payload 的包 src |
| 进程名输入 | 只支持 `--pid <int>` | 新增 `--pname <name>` 支持通配符 + 子进程聚合 |
| UDP 流对比 | 只对比 TCP,UDP 流被忽略 | UDP 流按时间序拼接 payload 参与对比 |
| 停止方式 | 默认 60 秒固定时长 | 默认无限,Ctrl+C 优雅退出(CancelKeyPress) |
| 实时统计 | 只有包数/字节数 | 新增 `--stats N` 每 N 秒打印 top 20 flows |
| `--flow <key>` | 不支持 | 支持只对比包含关键字的流 |
| `--bin <prefix>` | 不支持 | 支持同时导出每个 DIFF 流的原始字节 |
| `listproc <pname>` | 不存在 | 新增,列出所有匹配进程的 PID/连接数 |
| 可移植性 | 写死本地路径 | 完全基于脚本所在目录定位,无任何硬编码路径 |

---

## 六、常见问题

### Q1: `WinDivertOpen failed (error 2)`
→ WinDivert.dll 或 WinDivert64.sys 不在 exe 同目录。
检查 `windivert\WinDivert-2.2.2-A\x64\` 下是否有这两个文件。

### Q2: `WinDivertOpen failed (error 5)`
→ 没有管理员权限。以管理员身份打开 PowerShell。

### Q3: 抓不到任何包
→ 检查:
1. 驱动是否安装: `.\run.ps1 status` 应显示 `Running`
2. 目标进程是否真的有网络连接: `.\run.ps1 listpid <pname>` 看 TCP 数量
3. 用 `--full` 抓所有流量验证 WinDivert 本身正常

### Q4: 对比结果全是 ONLY-A / ONLY-B,没有 DIFF
→ 两次抓包的客户端端口不同(每次连接随机分配),无法聚合成同一 flow。
解决方案:
- 用 `--port 24863` 等指定固定端口对比
- 或用 `--flow 175.6.84.37` 按 IP 关键字过滤

### Q5: TLS 流量对比有意义吗?
→ TLS MITM 修改的流会出现 DIFF(保留前 5-12 字节 TLS 头,后面加密载荷全部不同)。
但若两次抓包端口不同,客户端端口变化会导致 flow key 不同,显示为 ONLY-A/ONLY-B。
建议用 `--port 443` 强制按端口聚合(忽略客户端端口)。

### Q6: 如何捕获模拟器(雷电/MuMu/夜神/腾讯手游助手)的流量?
→ 不同模拟器主进程名不同:
| 模拟器 | 主进程名 |
|--------|---------|
| 雷电模拟器 | `dnplayer.exe` + `LdVBoxHeadless.exe` |
| 腾讯手游助手 | `GameLoop.exe` / `QQPlayer.exe` |
| MuMu 模拟器 | `MuMuPlayer.exe` |
| 夜神模拟器 | `NoxVMHandle.exe` |

```powershell
# 雷电
.\run.ps1 capture cap.pcap --pname dnplayer* --stats 5
# 腾讯手游助手
.\run.ps1 capture cap.pcap --pname GameLoop* --stats 5
# 或直接抓全量
.\run.ps1 capture cap.pcap --full
```

### Q7: 编译源码
→ 使用 .NET Framework 4.0+ 的 csc.exe(Windows 自带):
```powershell
# 在管理员 PowerShell 中执行
$csc = 'C:\Windows\Microsoft.NET\Framework64\v4.0.30319\csc.exe'
$src  = '.\PacketTool.cs'
$out  = '.\windivert\WinDivert-2.2.2-A\x64\PacketTool.exe'
& $csc /nologo /platform:x64 /target:exe /optimize+ /out:$out $src
```
注意: exe 必须和 `WinDivert.dll`/`WinDivert64.sys` 同目录。

---

## 七、工作流最佳实践

### 7.1 验证 WPE/封包工具修改痕迹(最常用)

```powershell
# 1. 关闭封包工具,启动游戏到登录界面
# 2. 抓场景 A
.\run.ps1 capture captures\A.pcap --pname dnplayer* --stats 10
# (登录到大厅,停留 30 秒后 Ctrl+C 停止)

# 3. 启动封包工具(WPE/FightMaster),同样登录到大厅
# 4. 抓场景 B
.\run.ps1 capture captures\B.pcap --pname dnplayer* --stats 10
# (同样停留 30 秒后 Ctrl+C)

# 5. 字节级对比
.\run.ps1 compare captures\A.pcap captures\B.pcap `
    --report reports\diff.txt --detail --bin reports\diff

# 6. 对关键服务器流单独导出深入分析
.\run.ps1 dumpflow captures\A.pcap 175.6.84.37 24863 --out reports\A_24863
.\run.ps1 dumpflow captures\B.pcap 175.6.84.37 24863 --out reports\B_24863
```

### 7.2 只关心某个特定服务器

```powershell
# 直接按 IP 过滤
.\run.ps1 capture captures\anti.pcap --ip 175.6.84.37 --stats 5
```

### 7.3 抓全量(不知道目标 IP/端口时)

```powershell
.\run.ps1 capture captures\all.pcap --full --stats 5
```

---

## 八、技术实现说明

### 8.1 WinDivert 抓包层
- 使用 `WinDivertOpen(filter, LAYER_NETWORK, 0, FLAG_SNIFF|FLAG_RECV_ONLY)` 在网络层 sniff
- filter 表达式语法见 WinDivert 文档(类 BPF)
- 队列大小 64MB,队列长度 16384(防止高流量丢包)

### 8.2 TCP 流重组
- 按 SEQ 排序,处理重叠/重传/乱序
- SYN 包的 SEQ 作为 base,payload 从 SEQ+1 开始
- gap(丢包)用 0 填充

### 8.3 UDP 流重组
- 同 4 元组的所有 UDP payload 按时间戳顺序拼接
- 用于对比 DNS、QUIC、自定义 UDP 协议

### 8.4 flow key 设计
- 对称 4 元组: `(min_ip, min_port, max_ip, max_port)`,双向同一 key
- 这样 A 抓的客户端 50000→80 和 B 抓的客户端 50001→80 **不会**聚合成同一 flow
- 解决方案: 用 `--port 80` 强制按端口过滤

### 8.5 方向判定(c2s/s2c)
1. 优先找纯 SYN 包(`Flags & 0x02 != 0 && Flags & 0x10 == 0`),其 src 为 client
2. 无 SYN 时,取第一个有 payload 的包的 src 为 client
3. 退化到第一个包的 src 为 client

---

## 九、文件清单

| 文件 | 说明 |
|------|------|
| `PacketTool.cs` | 工具源码 v2.0 (C# .NET 4.0+) |
| `run.ps1` | 通用 PowerShell 包装脚本 v2.0 |
| `README.md` | 本使用说明 |
| `windivert\WinDivert-2.2.2-A\LICENSE` | WinDivert LGPLv3 许可证(法律必需) |
| `windivert\WinDivert-2.2.2-A\x64\PacketTool.exe` | 编译产物 v2.0 |
| `windivert\WinDivert-2.2.2-A\x64\WinDivert.dll` | P/Invoke DLL |
| `windivert\WinDivert-2.2.2-A\x64\WinDivert64.sys` | 内核驱动 |

---

## 十、版本历史

- **v2.0**: 通用化重写,修复 dumpflow/listpid/方向判定,新增 `--pname`/`--stats`/`--flow`/`--bin`/`listproc`, Ctrl+C 优雅退出,完全可移植(无硬编码路径)
- **v1.0**: 初版,基于 WinDivert 2.2.2,支持 `capture`/`compare`/`listpid`, FightMaster 专用 run.ps1
